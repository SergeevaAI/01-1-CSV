**Визуализация датасета

[Data-Science-Book](https://www.kaggle.com/datasets/mdwaquarazam/datasciencebook)

На дешборд [Data-Science-Book](https://datalens.yandex.ru/tync1pw0ll6ck-data-science-book)